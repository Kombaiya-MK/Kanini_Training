﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace UnderstandingCollectionsApp
{
    internal partial class Program
    {
        void sample()
        {
            int a = 2;
            Console.Write("kfkfnnff");
        }
        
    }
}
